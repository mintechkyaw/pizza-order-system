@extends('user.layouts.master')

@section('content')
    <h1>Hello</h1>
@endsection