<div>
    <input wire:model.live="search">

    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->users;
                                $__env->addLoop($__currentLoopData);
                                foreach ($__currentLoopData as $user) : $__env->incrementLoopIndices();
                                    $loop = $__env->getLastLoop(); ?>
        <div><?php echo e($user->name); ?></div>
    <?php endforeach;
                                $__env->popLoop();
                                $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH D:\laravelproject\pizza_order_system\resources\views/livewire/search-user.blade.php ENDPATH**/ ?>