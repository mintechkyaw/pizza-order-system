<?php $__env->startSection('title', 'Product List Page'); ?>

<?php $__env->startSection('product_focus'); ?>
    class="active has-sub"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('searchbar'); ?>
    <form class="form-header" action="<?php echo e(route('admin#products#search')); ?>" method="GET">
        <input class="au-input au-input--xl" type="text" name="searchKey"
            value="<?php if(isset($searchKey)): ?> <?php echo e($searchKey); ?> <?php endif; ?>" placeholder="Search for products.." />

        <button class="au-btn--submit" type="submit">
            <i class="zmdi zmdi-search"></i>
        </button>
    </form>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <div class="section__content section__content--p30">
            <div class="container-fluid">
                <div class="col-md-12">
                    <!-- DATA TABLE -->
                    <div class="table-data__tool">
                        <div class="table-data__tool-left">
                            <div class="overview-wrap">
                                <h2 class="title-1">Product List</h2>

                            </div>
                        </div>
                        <div class="table-data__tool-right">
                            <a href="<?php echo e(route('admin#product#createpage')); ?>">
                                <button class="au-btn au-btn-icon au-btn--green au-btn--small">
                                    <i class="zmdi zmdi-plus"></i>add product
                                </button>
                            </a>
                            <button class="au-btn au-btn-icon au-btn--green au-btn--small">
                                CSV download
                            </button>
                        </div>
                    </div>
                    <?php if(session('msg')): ?>
                        <?php if(session('msg') == 'product created successfully!'): ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <strong> <?php echo e(session('msg')); ?></strong>
                                <button type="button" class="btn-close" data-bs-dismiss="alert"
                                    aria-label="Close"></button>
                            </div>
                        <?php elseif(session('msg') == 'product deleted successfully!'): ?>
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <strong><?php echo e(session('msg')); ?></strong>
                                <button type="button" class="btn-close" data-bs-dismiss="alert"
                                    aria-label="Close"></button>
                            </div>
                        <?php elseif(session('msg') == 'product updated successfully!'): ?>
                            <div class="alert alert-primary alert-dismissible fade show" role="alert">
                                <strong><?php echo e(session('msg')); ?></strong>
                                <button type="button" class="btn-close" data-bs-dismiss="alert"
                                    aria-label="Close"></button>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>

                    <?php if($products && $products->count() > 0): ?>
                        <div class="table-responsive table-responsive-data2">
                            <table class="table table-data2 ">
                                <thead>
                                    <tr>
                                        <th>Product Image</th>
                                        <th>Product Name</th>
                                        <th>Product Description</th>
                                        <th>Category Name</th>
                                        <th>Price</th>
                                        <th>View Count</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="tr-shadow">
                                            <td style="width: 13%; ">
                                                <img src="<?php echo e(asset('storage/' . $product->product_photo_path)); ?>"
                                                    alt="productphoto" />
                                            </td>
                                            <td>
                                                <?php echo e($product->name); ?>

                                            </td>
                                            <td><?php echo e($product->description); ?></td>
                                            <td class="text-center"><?php echo e($product->category_name); ?>

                                            </td>
                                            <td class="text-center"><?php echo e($product->price); ?> Kyats </td>
                                            <td class="text-center"> <i class="zmdi zmdi-eye"></i>
                                                <?php echo e($product->view_count); ?> </td>
                                            <td>
                                                <div class="table-data-feature">
                                                    <a
                                                        href="<?php echo e(route('admin#product#updatepage', ['id' => $product->product_id])); ?>">
                                                        <button class="item mx-2" data-toggle="tooltip" data-placement="top"
                                                            title="Edit">
                                                            <i class="zmdi zmdi-edit"></i>
                                                        </button>
                                                    </a>

                                                    <form
                                                        action="<?php echo e(route('admin#product#delete', ['id' => $product->product_id])); ?>"
                                                        method="post">

                                                        <?php echo csrf_field(); ?>
                                                        <button type="submit" class="item mx-2" data-toggle="tooltip"
                                                            data-placement="top" title="Delete">
                                                            <i class="zmdi zmdi-delete"></i>
                                                        </button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr class="spacer"></tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </tbody>
                            </table>
                            <?php echo e($products->links()); ?>

                        </div>
                    <?php else: ?>
                        <p class="mt-3 h3 text-center ">No Data Found!</p>
                    <?php endif; ?>
                    <!-- END DATA TABLE -->
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravelproject\pizza_order_system\resources\views/admin/products/list.blade.php ENDPATH**/ ?>