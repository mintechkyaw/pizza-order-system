<?php $__env->startSection('title', 'pizza cart'); ?>

<?php $__env->startSection('order_focus', 'active'); ?>




<?php $__env->startSection('content'); ?>
    <!-- Order Start -->
    <div class="container-fluid">
        <div class="row px-xl-5">
            <div class="col-lg-9 table-responsive mb-5 mx-auto">
                <?php if($order && $order->count() > 0): ?>
                    <table class="table table-light table-borderless table-hover text-center mb-0">
                        <thead class="thead-dark">
                            <tr>
                                <th>Date</th>
                                <th>Order ID</th>
                                <th>Total Price</th>
                                <th>Status</th>
                                <th>Products</th>
                            </tr>
                        </thead>

                        <tbody class="align-middle">
                            <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="align-middle"><?php echo e(date('j-M-Y', strtotime($item->order_date))); ?></td>
                                    <td class="align-middle"><?php echo e($item->order_code); ?> </td>
                                    <td class="align-middle"><?php echo e($item->total_price); ?> Kyats </td>
                                    <?php if($item->status == 'pending'): ?>
                                        <td class="align-middle text-muted"><i
                                                class="fa-solid fa-pizza-slice mx-2"></i><?php echo e($item->status); ?> </td>
                                    <?php elseif($item->status == 'processing'): ?>
                                        <td class="align-middle text-warning"><i
                                                class="fa-solid fa-utensils mx-2"></i><?php echo e($item->status); ?> </td>
                                    <?php elseif($item->status == 'delivered'): ?>
                                        <td class="align-middle text-success"><i class="fas fa-box text-success mx-2"></i>
                                            <?php echo e($item->status); ?> </td>
                                    <?php elseif($item->status == 'rejected'): ?>
                                        <td class="align-middle text-danger"><i
                                                class="fa-solid fa-thumbs-down mx-2"></i><?php echo e($item->status); ?> </td>
                                    <?php endif; ?>
                                    <td>
                                        <button class="btn btn-primary rounded">Ordered Products</button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                    <hr>
                    <?php echo e($order->links()); ?>

                <?php else: ?>
                    <p class="mt-3 h3 text-center ">No Data Found!</p>
                <?php endif; ?>
            </div>

        </div>
    </div>
    <!-- Order End -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravelproject\pizza_order_system\resources\views/user/order/list.blade.php ENDPATH**/ ?>