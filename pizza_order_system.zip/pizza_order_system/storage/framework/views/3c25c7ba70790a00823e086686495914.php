<?php $__env->startSection('title', 'Product Update Page'); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <div class="section__content section__content--p30">
            <div class= "container-fluid">
                <div class="col-lg-7 offset-2">
                    <div class="card">
                        <form class="card-body" action="<?php echo e(route('admin#product#update', ['id' => $product->product_id])); ?>"
                            method="post" style="display: block" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <h3 class="card-title text-center title-1">Edit Your Product Info</h3>
                            <div class="d-flex py-3 align-items-center">
                                <label for="product-img" class="border border-3">
                                    <?php if($product->name): ?>
                                        <img class="card-img profileimage"
                                            src="<?php echo e(asset('storage/' . $product->product_photo_path)); ?>"
                                            alt="<?php echo e(Auth::user()->name); ?>">
                                    <?php else: ?>
                                        <img class="card-img profileimage" src="<?php echo e(asset('image/defaultprofile.png')); ?>"
                                            alt="<?php echo e(Auth::user()->name); ?>">
                                    <?php endif; ?>

                                    <?php $__errorArgs = ['productPhoto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </label>

                                <input style="display:none" type="file" name="productPhoto" id="product-img">

                                <div class="mx-5 card-text text-dark">
                                    <div>
                                        <div class="d-flex my-2"><label for="name"><i
                                                    class="fas fa-pizza-slice me-2"></i></label>
                                            <input id="name" name="productName" type="text"
                                                class="mb-2 <?php $__errorArgs = ['categoryName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                value="<?php echo e(old('productName', $product->name)); ?>">
                                        </div>
                                        <?php $__errorArgs = ['productName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger">
                                                <?php echo e($message); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div>
                                        <div class="d-flex my-2"><label for="category"><i
                                                    class="fa-solid fa-table-cells-large me-2"></i></label>
                                            <select class="border-0 <?php $__errorArgs = ['categoryId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                name="categoryId" id="category-name">
                                                <option value="">Choose Pizza Category</option>
                                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($category->category_id); ?>"
                                                        <?php if($category->category_id == $product->category_id): echo 'selected'; endif; ?>>
                                                        <?php echo e($category->name); ?> </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <?php $__errorArgs = ['categoryId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger">
                                                <?php echo e($message); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div>
                                        <div class="d-flex  my-2"><label for="email"><i
                                                    class="fa-solid fa-align-left me-2"></i></label>
                                            <textarea class="<?php $__errorArgs = ['productDescription'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>border border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="productDescription" id=""
                                                cols="30" rows="1"><?php echo e(old('productDescription', $product->description)); ?></textarea>

                                        </div>
                                        <?php $__errorArgs = ['productDescription'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger">
                                                <?php echo e($message); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div>
                                        <div class="d-flex my-2"><label for="price"><i
                                                    class="fas fa-dollar-sign me-2"></i></label>
                                            <input style="width: fit-content" id="price" name="productPrice"
                                                type="text"
                                                class="mb-2 <?php $__errorArgs = ['productPrice'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                value="<?php echo e(old('productPrice', $product->price)); ?>"> Kyats

                                        </div>
                                        <?php $__errorArgs = ['productPrice'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger">
                                                <?php echo e($message); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div>
                                        <div class="d-flex  my-2"><label for="address"><i
                                                    class="fa-solid fa-hourglass-half mt-2 me-2"></i></label>
                                            <select class="border-0 <?php $__errorArgs = ['waitingTimes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                name="waitingTimes" id="waiting-times">
                                                <option value="">Choose Waiting Times</option>
                                                <option value="15" <?php if($product->waiting_times == 15): echo 'selected'; endif; ?>>15 min</option>
                                                <option value="20" <?php if($product->waiting_times == 20): echo 'selected'; endif; ?>>20 min</option>
                                                <option value="25" <?php if($product->waiting_times == 25): echo 'selected'; endif; ?>>25 min</option>
                                                <option value="30" <?php if($product->waiting_times == 30): echo 'selected'; endif; ?>>30 min</option>
                                                <option value="35" <?php if($product->waiting_times == 36): echo 'selected'; endif; ?>>35 min</option>
                                                <option value="40" <?php if($product->waiting_times == 40): echo 'selected'; endif; ?>>40 min</option>
                                            </select>
                                        </div>
                                        <?php $__errorArgs = ['waitingTimes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger">
                                                <?php echo e($message); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <button type="submit" class="py-2 form-control btn btn-info" onclick="toggleEdit()"><i
                                    class="fa-solid fa-floppy-disk"></i> Save
                                Your Product Info...</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    <textarea id="myTextarea"></textarea>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravelproject\pizza_order_system\resources\views/admin/products/update.blade.php ENDPATH**/ ?>