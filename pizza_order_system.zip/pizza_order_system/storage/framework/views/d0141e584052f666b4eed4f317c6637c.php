<?php $__env->startSection('title', 'Admin List Page'); ?>

<?php $__env->startSection('admin_list_focus'); ?>
    class= "active has-sub"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('searchbar'); ?>
    <form class="form-header" action="<?php echo e(route('admin#search')); ?>" method="GET">
        <input class="au-input au-input--xl" type="text" name="searchKey"
            value="<?php if(isset($searchKey)): ?> <?php echo e($searchKey); ?> <?php endif; ?>" placeholder="Search for products.." />

        <button class="au-btn--submit" type="submit">
            <i class="zmdi zmdi-search"></i>
        </button>
    </form>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <div class="section__content section__content--p30">
            <div class="container-fluid">
                <div class="col-md-12">
                    <!-- DATA TABLE -->
                    <div class="table-data__tool">
                        <div class="table-data__tool-left">
                            <div class="overview-wrap">
                                <h2 class="title-1">Admin List</h2>

                            </div>
                        </div>
                        <div class="table-data__tool-right">
                            <button class="au-btn au-btn-icon au-btn--green au-btn--small">
                                CSV download
                            </button>
                        </div>
                    </div>

                    <?php if(session('msg')): ?>
                        <div class="alert alert-warning alert-dismissible fade show" role="alert">
                            <strong> <?php echo e(session('msg')); ?></strong>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <?php if($admins && $admins->count() > 0): ?>
                        <div class="table-responsive table-responsive-data2">
                            <table class="table table-data2 text-center  ">
                                <thead>
                                    <tr>
                                        <th>Profile photo</th>
                                        <th>Name</th>
                                        <th>email</th>
                                        <th>phone</th>
                                        <th>address</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="tr-shadow">
                                            <td style="width: 13%; ">
                                                <?php if($user->profile_photo_path): ?>
                                                    <img src="<?php echo e(asset('storage/' . $user->profile_photo_path)); ?>"
                                                        alt="adminphoto" />
                                                <?php else: ?>
                                                    <img src="<?php echo e(asset('image/defaultprofile.png')); ?>" alt="adminphoto">
                                                <?php endif; ?>

                                            </td>
                                            <td>
                                                <?php echo e($user->name); ?>

                                            </td>
                                            <td><?php echo e($user->email); ?></td>
                                            <td class="text-center"><?php echo e($user->phone); ?>

                                            </td>
                                            <td class="text-center"><?php echo e($user->address); ?></td>
                                            <td>
                                                <div class="table-data-feature">
                                                    <?php if(Auth::user()->name == $user->name): ?>
                                                        <a href="<?php echo e(route('admin#account#profilepage')); ?>">
                                                            <button class="item mx-2" data-toggle="tooltip"
                                                                data-placement="top" title="Info">
                                                                <i class="zmdi zmdi-eye"></i>
                                                            </button></a>
                                                    <?php else: ?>
                                                        <a href="<?php echo e(route('admin#role#change', ['id' => $user->id])); ?>">
                                                            <button class="item mx-2" data-toggle="tooltip"
                                                                data-placement="top" title="Role Change">
                                                                <i class="fa-solid fa-user-xmark"></i>
                                                            </button>
                                                        </a>
                                                        <form action="<?php echo e(route('admin#delete', ['id' => $user->id])); ?>"
                                                            method="post">

                                                            <?php echo csrf_field(); ?>
                                                            <button type="submit" class="item mx-2" data-toggle="tooltip"
                                                                data-placement="top" title="Delete">
                                                                <i class="zmdi zmdi-delete"></i>
                                                            </button>
                                                        </form>
                                                    <?php endif; ?>

                                                </div>
                                            </td>
                                        </tr>
                                        <tr class="spacer"></tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </tbody>
                            </table>
                            <?php echo e($admins->links()); ?>

                        </div>
                    <?php else: ?>
                        <p class="mt-3 h3 text-center ">No Data Found!</p>
                    <?php endif; ?>
                    <!-- END DATA TABLE -->
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravelproject\pizza_order_system\resources\views/admin/permissions/list.blade.php ENDPATH**/ ?>