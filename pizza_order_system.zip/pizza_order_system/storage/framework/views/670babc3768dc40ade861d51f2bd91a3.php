<?php $__env->startSection('title', 'pizza cart'); ?>

<?php $__env->startSection('cart_focus', 'active'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Cart Start -->
    <div class="container-fluid">
        <?php if($cart && $cart->count() > 0): ?>
            <div class="row px-xl-5">

                <div id="cart-list" class="col-lg-8 table-responsive mb-5">

                    <table class="table table-light table-borderless table-hover text-center mb-0">
                        <thead class="thead-dark">
                            <tr>
                                <th>Products</th>
                                <th>Price</th>
                                <th>Quantity</th>
                                <th>Total</th>
                                <th>Remove</th>
                            </tr>
                        </thead>

                        <tbody class="align-middle">

                            <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <input type="hidden" id="productId" value="<?php echo e($item->product_id); ?>">

                                    <td class="align-middle"><?php echo e($item->pizza_name); ?></td>
                                    <td class="align-middle"><?php echo e($item->price); ?> Kyats </td>
                                    <td class="align-middle">
                                        <input type="hidden" id="cartId" value="<?php echo e($item->cart_id); ?>">

                                        <div class="input-group quantity mx-auto" style="width: 100px;">
                                            <div class="input-group-btn">
                                                <button class="btn btn-sm btn-primary btn-minus">
                                                    <i class="fa fa-minus"></i>
                                                </button>
                                            </div>
                                            <input type="text" id="qty"
                                                class="form-control form-control-sm bg-secondary border-0 text-center"
                                                value="<?php echo e($item->qty); ?>">
                                            <div class="input-group-btn">
                                                <button class="btn btn-sm btn-primary btn-plus">
                                                    <i class="fa fa-plus"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="align-middle" id="total"><?php echo e($item->price * $item->qty); ?> Kyats</td>
                                    <td class="align-middle"><button class="btn btn-sm btn-danger rounded btn-remove"><i
                                                class="fa fa-times"></i></button></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </tbody>
                    </table>
                    <hr>
                    <?php echo e($cart->links()); ?>



                </div>
                <div class="col-lg-4">
                    <h5 class="section-title position-relative text-uppercase mb-3"><span class="bg-secondary pr-3">Cart
                            Summary</span></h5>
                    <div class="bg-light p-30 mb-5">
                        <div class="border-bottom pb-2">
                            <div class="d-flex justify-content-between mb-3">
                                <h6>Subtotal</h6>
                                <h6 id="sub-total"><?php echo e($subTotal); ?></h6>
                            </div>
                            <div class="d-flex justify-content-between">
                                <h6 class="font-weight-medium">Delivery</h6>
                                <h6 class="font-weight-medium">3000</h6>
                            </div>
                        </div>
                        <div class="pt-2">
                            <div class="d-flex justify-content-between mt-2">
                                <h5>Total</h5>
                                <h5 id="total-price">
                                    <?php echo e($totalPrice); ?> Kyats
                                </h5>
                            </div>
                            <a id="checkout" class="btn btn-block btn-primary font-weight-bold my-3 py-3"
                                href="<?php echo e(route('order')); ?>">Proceed
                                To Checkout</a><button id="clearcart"
                                class="btn btn-block btn-primary font-weight-bold my-3 py-3">Clear Cart</button>
                        </div>

                    </div>
                </div>

            </div>
        <?php else: ?>
            <p class="mt-3 h3 text-center ">No Data Found!</p>
        <?php endif; ?>
    </div>
    <!-- Cart End -->
<?php $__env->stopSection(); ?>


<?php $__env->startPush('script'); ?>
    <script>
        $(document).ready(function() {
            $('.btn-plus').click(function() {
                $parentNode = $(this).parents('tr');
                $.ajax({
                    url: 'http://127.0.0.1:8000/user/editcart',
                    type: 'get',
                    dataType: 'json',
                    data: {
                        'cartId': $parentNode.find('#cartId').val(),
                        'quantity': $parentNode.find('#qty').val()
                    },
                    success: function(response) {
                        $parentNode.find('#total').html(response.data[0]['qty'] * response.data[
                            0]['price'] + ' Kyats')
                        $('#sub-total').html(response.subtotal)
                        $('#total-price').html(response.totalprice + ' Kyats')
                    }
                })
            })

            $('.btn-minus').click(function() {
                $parentNode = $(this).parents('tr');
                $.ajax({
                    url: 'http://127.0.0.1:8000/user/editcart',
                    type: 'get',
                    dataType: 'json',
                    data: {
                        'cartId': $parentNode.find('#cartId').val(),
                        'quantity': $parentNode.find('#qty').val()
                    },
                    success: function(response) {
                        $parentNode.find('#total').html(response.data[0]['qty'] * response.data[
                            0]['price'] + ' Kyats')
                        $('#sub-total').html(response.subtotal)
                        $('#total-price').html(response.totalprice + ' Kyats')
                    }
                })
            })

            $('.btn-remove').click(function() {
                $parentNode = $(this).parents('tr');
                $.ajax({
                    url: 'http://127.0.0.1:8000/user/deletecart',
                    type: 'get',
                    dataType: 'json',
                    data: {
                        'cartId': $parentNode.find('#cartId').val()
                    },
                    success: function(response) {
                        $parentNode.remove();
                        $('#sub-total').html(response.subtotal)
                        $('#total-price').html(response.totalprice + ' Kyats')
                    }
                })
            })

            $('#clearcart').click(function() {
                $.ajax({
                    url: 'http://127.0.0.1:8000/user/clearcart',
                    type: 'get',
                    success: function(response) {
                        $('#cart-list').html(
                            '<p class="mt-3 h3 text-center ">No Data Found!</p>')
                        $('#checkout').remove()
                        $('#total-price').html('0 Kyats')
                        $('#sub-total').html('0')
                    }
                })
            })


        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('user.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravelproject\pizza_order_system\resources\views/user/cart/list.blade.php ENDPATH**/ ?>