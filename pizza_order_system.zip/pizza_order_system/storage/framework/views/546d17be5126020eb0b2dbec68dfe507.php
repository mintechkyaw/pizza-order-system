<?php $__env->startSection('title', 'Pizza Buddy'); ?>

<?php $__env->startSection('home_focus', 'active'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row px-xl-5">
            <!-- Shop Sidebar Start -->
            <div class="col-lg-3 col-md-4">


                <!-- Category Start -->
                <h5 class="section-title position-relative text-uppercase mb-3"><span class="bg-secondary pr-3">Filter
                        by category</span></h5>
                <div class="bg-light p-4 mb-30">
                    <form action="<?php echo e(route('user#shop')); ?>" method="GET">
                        <div class="custom-control custom-checkbox d-flex align-items-center justify-content-between mb-3">
                            <input name="categoryId" type="checkbox" class="custom-control-input" checked id="category-all"
                                onchange="this.form.submit()">
                            <label class="custom-control-label" for="category-all">All Color</label>
                            <span class="badge border font-weight-normal">1000</span>
                        </div>


                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div
                                class="custom-control custom-checkbox d-flex align-items-center justify-content-between mb-3">

                                <input name="categoryId" type="checkbox" <?php if($msg == $category->category_id): echo 'checked'; endif; ?>
                                    value="<?php echo e($category->category_id); ?>" class="custom-control-input"
                                    id="<?php echo e($category->name); ?>" onchange="this.form.submit()">
                                <label class="custom-control-label"
                                    for="<?php echo e($category->name); ?>"><?php echo e($category->name); ?></label>
                                <span class="badge border font-weight-normal">1000</span>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <input type="submit" value="hehe" class="d-none">
                    </form>
                </div>
                <!-- Category End -->



                <div class="">
                    <a href="<?php echo e(route('order')); ?>"><button class="btn btn btn-warning w-100">Order</button></a>
                </div>

            </div>
            <!-- Shop Sidebar End -->


            <!-- Shop Product Start -->
            <div class="col-lg-9 col-md-8">
                <div class="row pb-3">
                    <div class="col-12 pb-1">
                        <div class="d-flex align-items-center justify-content-between mb-4">
                            <div>
                                <button class="btn btn-sm btn-light"><i class="fa fa-th-large"></i></button>
                                <button class="btn btn-sm btn-light ml-2"><i class="fa fa-bars"></i></button>
                            </div>
                            <div class="ml-2">
                                <div class="btn-group">
                                    <button id="sorting" type="button" class="btn btn-sm btn-light dropdown-toggle"
                                        data-toggle="dropdown">Sorting</button>
                                    <div class="dropdown-menu dropdown-menu-right">
                                        <button id="pLow" class="dropdown-item bg-secondary">
                                            price: low - high</button>
                                        <button id="phigh" class="dropdown-item bg-secondary">
                                            price: high - low</button>
                                        <button id="vLow" class="dropdown-item bg-secondary">
                                            view: low - high</button>
                                        <button id="vhigh" class="dropdown-item bg-secondary">
                                            view: high - low</button>
                                    </div>
                                </div>
                                <div class="btn-group ml-2">
                                    <button type="button" class="btn btn-sm btn-light dropdown-toggle"
                                        data-toggle="dropdown">Showing</button>
                                    <div class="dropdown-menu dropdown-menu-right">
                                        <a class="dropdown-item bg-secondary" href="#">10</a>
                                        <a class="dropdown-item bg-secondary" href="#">20</a>
                                        <a class="dropdown-item bg-secondary" href="#">30</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php if($datas->count() > 0): ?>
                        <div id="productList" class="row">
                            <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-4 col-md-6 col-sm-6 pb-1">
                                    <div class="product-item bg-light mb-4">
                                        <div class="product-img position-relative overflow-hidden">
                                            <img id="productPhoto" class="img-fluid w-100"
                                                src="<?php echo e(asset('storage/' . $product->product_photo_path)); ?>" alt="">

                                        </div>

                                        <div class=" text-center py-4">
                                            <input type="hidden" id="product-id" value="<?php echo e($product->product_id); ?>">
                                            <a id="productId" class="h6 text-decoration-none text-truncate"
                                                href="<?php echo e(route('user#pizza#details', ['id' => $product->product_id])); ?>"
                                                id="productName"><?php echo e($product->name); ?> </a>
                                            <div class="d-flex align-items-center justify-content-center mt-2">
                                                <h5 id="productPrice"><?php echo e($product->price); ?> Kyats </h5>

                                            </div>
                                            <div id="productView"
                                                class="d-flex align-items-center justify-content-center mb-1">
                                                view - <?php echo e($product->view_count); ?>

                                            </div>
                                        </div>


                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php else: ?>
                    <?php endif; ?>

                </div>
            </div>
            <!-- Shop Product End -->
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('script'); ?>
    <script>
        $(document).ready(function() {
            $('#pLow').click(function() {
                $('#sorting').text('price: low to high')
                $.ajax({
                    url: 'http://127.0.0.1:8000/user/productfilter',
                    type: 'get',
                    data: {
                        'status': 'pLow'
                    },
                    dataType: 'json',
                    success: function(response) {
                        var $list;
                        $.each(response, function(index, product) {
                            $list += `
                            <div class="col-lg-4 col-md-6 col-sm-6 pb-1">
                                <div class="product-item bg-light mb-4">
                                    <div class="product-img position-relative overflow-hidden">
                                        <img id="productPhoto" class="img-fluid w-100"
                                            src="<?php echo e(asset('storage/${product.product_photo_path}')); ?>" alt="">

                                    </div>

                                        <div class="col text-center py-4">
                                            <a id="productId" class="h6 text-decoration-none text-truncate"

                                                id="productName">${product.name}</a>
                                            <div class="d-flex align-items-center justify-content-center mt-2">
                                                <h5 id="productPrice">${product.price} Kyats </h5>

                                            </div>
                                            <div id="productView"
                                                class="d-flex align-items-center justify-content-center mb-1">
                                                view - ${product.view_count}
                                            </div>
                                        </div>


                                </div>
                            </div>

                            `
                            $('#productList').html($list);

                        })
                    }
                })
            });

            $('#phigh').click(function() {
                $('#sorting').text('price: high to low')

                $.ajax({
                    url: 'http://127.0.0.1:8000/user/productfilter',
                    type: 'get',
                    data: {
                        'status': 'phigh'
                    },
                    dataType: 'json',
                    success: function(response) {
                        var $list;
                        $.each(response, function(index, product) {
                            $list += `
                            <div class="col-lg-4 col-md-6 col-sm-6 pb-1">
                                <div class="product-item bg-light mb-4">
                                    <div class="product-img position-relative overflow-hidden">
                                        <img id="productPhoto" class="img-fluid w-100"
                                            src="<?php echo e(asset('storage/${product.product_photo_path}')); ?>" alt="">

                                    </div>

                                        <div class="col text-center py-4">
                                            <a id="productId" class="h6 text-decoration-none text-truncate"
                                            href=""
                                                id="productName">${product.name}</a>
                                            <div class="d-flex align-items-center justify-content-center mt-2">
                                                <h5 id="productPrice">${product.price} Kyats </h5>

                                            </div>
                                            <div id="productView"
                                                class="d-flex align-items-center justify-content-center mb-1">
                                                view - ${product.view_count}
                                            </div>
                                        </div>


                                </div>
                            </div>

                            `
                            $('#productList').html($list);

                        })
                    }
                })
            });

            $('#vLow').click(function() {
                $('#sorting').text('view: low to high')

                $.ajax({
                    url: 'http://127.0.0.1:8000/user/productfilter',
                    type: 'get',
                    data: {
                        'status': 'vLow'
                    },
                    dataType: 'json',
                    success: function(response) {
                        var $list;
                        $.each(response, function(index, product) {
                            $list += `
                            <div class="col-lg-4 col-md-6 col-sm-6 pb-1">
                                <div class="product-item bg-light mb-4">
                                    <div class="product-img position-relative overflow-hidden">
                                        <img id="productPhoto" class="img-fluid w-100"
                                            src="<?php echo e(asset('storage/${product.product_photo_path}')); ?>" alt="">

                                    </div>

                                        <div class="col text-center py-4">
                                            <a id="productId" class="h6 text-decoration-none text-truncate"
                                            href=""
                                                id="productName">${product.name}</a>
                                            <div class="d-flex align-items-center justify-content-center mt-2">
                                                <h5 id="productPrice">${product.price} Kyats </h5>

                                            </div>
                                            <div id="productView"
                                                class="d-flex align-items-center justify-content-center mb-1">
                                                view - ${product.view_count}
                                            </div>
                                        </div>


                                </div>
                            </div>

                            `
                            $('#productList').html($list);

                        })
                    }
                })
            });

            $('#vhigh').click(function() {
                $('#sorting').text('view: high to low')
                $.ajax({
                    url: 'http://127.0.0.1:8000/user/productfilter',
                    type: 'get',
                    data: {
                        'status': 'vhigh'
                    },
                    dataType: 'json',
                    success: function(response) {
                        var $list;
                        $.each(response, function(index, product) {
                            $list += `
                            <div class="col-lg-4 col-md-6 col-sm-6 pb-1">
                                <div class="product-item bg-light mb-4">
                                    <div class="product-img position-relative overflow-hidden">
                                        <img id="productPhoto" class="img-fluid w-100"
                                            src="<?php echo e(asset('storage/${product.product_photo_path}')); ?>" alt="">

                                    </div>

                                        <div class="col text-center py-4">
                                            <a id="productId" class="h6 text-decoration-none text-truncate"
                                            href=""
                                                id="productName">${product.name}</a>
                                            <div class="d-flex align-items-center justify-content-center mt-2">
                                                <h5 id="productPrice">${product.price} Kyats </h5>

                                            </div>
                                            <div id="productView"
                                                class="d-flex align-items-center justify-content-center mb-1">
                                                view - ${product.view_count}
                                            </div>
                                        </div>


                                </div>
                            </div>

                            `
                            $('#productList').html($list);

                        })
                    }
                })
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('user.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravelproject\pizza_order_system\resources\views/user/shop/shop.blade.php ENDPATH**/ ?>