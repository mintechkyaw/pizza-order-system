<?php $__env->startSection('title', 'Home Page'); ?>

<?php $__env->startSection('home_focus'); ?>
    class="active has-sub"
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <div class="section__content section__content--p30">
            <div class="container-fluid text-justify">
                <div class="row">
                    <div class="card col m-2 " style="width: 18rem;">

                        <div class="card-body rounded">
                            <h5 class="card-title">Active User - <?php echo e($customers->count()); ?></h5>
                            <p class="card-text">There are currently <?php echo e($customers->count()); ?> of Active users.</p>
                        </div>
                        <a href="<?php echo e(route('admin#customer#list')); ?>" class="form-control btn btn-primary mb-2">Customer
                            List</a>

                    </div>
                    <div class="card col m-2 " style="width: 18rem;">

                        <div class="card-body rounded">
                            <h5 class="card-title">Active Admin - <?php echo e($admins->count()); ?></h5>
                            <p class="card-text">There are currently <?php echo e($admins->count()); ?> of Active users.</p>
                        </div>
                        <a href="<?php echo e(route('admin#customer#list')); ?>" class="form-control btn btn-primary mb-2">Customer
                            List</a>

                    </div>
                    <div class="card col m-2 " style="width: 18rem;">

                        <div class="card-body rounded">
                            <h5 class="card-title">Active Admin - 0</h5>
                            <p class="card-text">There are currently 0 of Active admins.</p>
                        </div>
                        <a href="<?php echo e(route('admin#list')); ?>" class="form-control btn btn-primary mb-2">Customer
                            List</a>

                    </div>
                </div>
                <div class="row">
                    <div class="card col m-2" style="width: 18rem;">
                        <img src="..." class="card-img-top" alt="...">
                        <div class="card-body ">
                            <h5 class="card-title">Most Sold Item</h5>
                            <p class="card-text">Some quick example text to build on the card title and make up the bulk of
                                the
                                card's content.</p>
                            <a href="<?php echo e(route('admin#products#list')); ?>" class="form-control mb-2 btn btn-primary">Product
                                List</a>
                        </div>
                    </div>
                    <div class="card col m-2" style="width: 18rem;">
                        <img src="..." class="card-img-top" alt="...">
                        <div class="card-body ">
                            <h5 class="card-title">Most View Item</h5>
                            <p class="card-text">Some quick example text to build on the card title and make up the bulk of
                                the
                                card's content.</p>
                            <a href="<?php echo e(route('admin#products#list')); ?>" class="form-control mb-2 btn btn-primary">Product
                                List</a>
                        </div>
                    </div>
                    <div class="card col m-2" style="width: 18rem;">
                        <img src="..." class="card-img-top" alt="...">
                        <div class="card-body ">
                            <h5 class="card-title">Most Sold Item</h5>
                            <p class="card-text">Some quick example text to build on the card title and make up the bulk of
                                the
                                card's content.</p>
                            <a href="<?php echo e(route('admin#products#list')); ?>" class="form-control mb-2 btn btn-primary">Product
                                List</a>
                        </div>
                    </div>
                    <div class="card col m-2" style="width: 18rem;">
                        <img src="..." class="card-img-top" alt="...">
                        <div class="card-body ">
                            <h5 class="card-title">Most Sold Item</h5>
                            <p class="card-text">Some quick example text to build on the card title and make up the bulk of
                                the
                                card's content.</p>
                            <a href="<?php echo e(route('admin#products#list')); ?>" class="form-control mb-2 btn btn-primary">Product
                                List</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravelproject\pizza_order_system\resources\views/admin/home.blade.php ENDPATH**/ ?>