<?php $__env->startSection('title', 'Order List Page'); ?>

<?php $__env->startSection('order_focus'); ?>
    class="active has-sub"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('searchbar'); ?>
    <form class="form-header" action="<?php echo e(route('admin#orders#search')); ?>" method="GET">
        <input class="au-input au-input--xl" type="text" name="searchKey"
            value="<?php if(isset($searchKey)): ?> <?php echo e($searchKey); ?> <?php endif; ?>" placeholder="Search for orders.." />

        <button class="au-btn--submit" type="submit">
            <i class="zmdi zmdi-search"></i>
        </button>
    </form>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <div class="section__content section__content--p30">
            <div class="container-fluid">
                <div class="col-md-12">
                    <!-- DATA TABLE -->
                    <div class="table-data__tool">
                        <div class="table-data__tool-left">
                            <div class="overview-wrap">
                                <h2 class="title-1">Order List</h2>

                            </div>
                        </div>
                        <form class="table-data__tool-right" action="<?php echo e(route('admin#orders#list')); ?>">
                            <select name="filterStatus" class="au-btn au-btn-icon au-btn--green au-btn--small px-4 py-2">
                                <option class="bg-dark" value="">All</option>
                                <option class="bg-info" <?php if(request('filterStatus') == 'pending'): echo 'selected'; endif; ?> value="pending">Pending</option>
                                <option class="bg-warning" <?php if(request('filterStatus') == 'processing'): echo 'selected'; endif; ?> value="processing">Processing
                                </option>
                                <option class="bg-success" <?php if(request('filterStatus') == 'delivered'): echo 'selected'; endif; ?> value="delivered">Delivered</option>
                                <option class="bg-danger" <?php if(request('filterStatus') == 'rejected'): echo 'selected'; endif; ?> value="rejected">Rejected</option>
                            </select>

                            <button type="submit" class="au-btn au-btn-icon au-btn--green au-btn--small">
                                Apply Filter
                            </button>
                        </form>
                    </div>


                    <div class="msg">

                    </div>


                    <?php if($orders && $orders->count() > 0): ?>
                        <div class="table-responsive table-responsive-data2">
                            <table class="table table-data2 ">
                                <thead>
                                    <tr>
                                        <th>User ID</th>
                                        <th>User Name</th>
                                        <th>Order Date</th>
                                        <th>Order Code</th>
                                        <th>Amount</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody id="order-data">
                                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <input type="hidden" id="orderId" value="<?php echo e($order->order_id); ?>">
                                            <td><?php echo e($order->user_id); ?> </td>
                                            <td><?php echo e($order->name); ?> </td>
                                            <td><?php echo e(date('j-M-Y', strtotime($order->order_date))); ?></td>
                                            <td><a
                                                    href="<?php echo e(route('admin#order#list', ['ordercode' => $order->order_code])); ?>"><?php echo e($order->order_code); ?>

                                                </a></td>
                                            <td><?php echo e($order->total_price); ?> Kyats </td>

                                            <td>
                                                <select class='form-select' name="" id="orderstatus">
                                                    <option <?php if($order->status == 'pending'): echo 'selected'; endif; ?> value="pending">Pending</option>
                                                    <option <?php if($order->status == 'processing'): echo 'selected'; endif; ?> value="processing">Processing
                                                    </option>
                                                    <option <?php if($order->status == 'delivered'): echo 'selected'; endif; ?> value="delivered">Delivered
                                                    </option>
                                                    <option <?php if($order->status == 'rejected'): echo 'selected'; endif; ?> value="rejected">Rejected</option>
                                                </select>

                                            </td>
                                            <td>
                                                <button class="btn btn-primary confirm" id="confirm">Confirm</button>
                                            </td>
                                        </tr>
                                        <tr class="spacer"></tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </tbody>
                            </table>
                            <hr>
                            <?php echo e($orders->links()); ?>

                        </div>
                    <?php else: ?>
                        <p class="mt-3 h3 text-center ">No Data Found!</p>
                    <?php endif; ?>
                    <!-- END DATA TABLE -->
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        $(document).ready(function() {
            $('.confirm').click(function() {
                $parentNode = $(this).parents('tr');
                $status = $parentNode.find('#orderstatus').val();
                $orderid = $parentNode.find('#orderId').val();
                console.log($status);
                console.log($orderid);
                $.ajax({
                    url: 'http://127.0.0.1:8000/admin/orderstatus',
                    type: 'get',
                    dataType: 'json',
                    data: {
                        'status': $status,
                        'orderid': $orderid
                    },
                    success: function(response) {
                        if (response.msg == 'Order Pending Success!') {
                            $data = `<div class="alert alert-info alert-dismissible fade show" role="alert">
                                    <strong > ${response.msg} </strong>
                                    <button type="button" class="btn-close" data-bs-dismiss="alert"
                                        aria-label="Close"></button>
                                </div>`
                        } else if (response.msg == 'Order Processing Success!') {
                            $data = `<div class="alert alert-warning alert-dismissible fade show" role="alert">
                                    <strong > ${response.msg} </strong>
                                    <button type="button" class="btn-close" data-bs-dismiss="alert"
                                        aria-label="Close"></button>
                                </div>`
                        } else if (response.msg == 'Order Delivering Success!') {
                            $data = `<div class="alert alert-success alert-dismissible fade show" role="alert">
                                    <strong > ${response.msg} </strong>
                                    <button type="button" class="btn-close" data-bs-dismiss="alert"
                                        aria-label="Close"></button>
                                </div>`
                        } else if (response.msg == 'Order Rejecting Success!') {
                            $data = `<div class="alert alert-danger alert-dismissible fade show" role="alert">
                                    <strong > ${response.msg} </strong>
                                    <button type="button" class="btn-close" data-bs-dismiss="alert"
                                        aria-label="Close"></button>
                                </div>`
                        }
                        $('.msg').html($data)
                    }

                })
            })

            // $('#filter-status').change(function() {
            //     $fliterStatus = $(this).val()
            //     $.ajax({
            //         url: 'http://127.0.0.1:8000/admin/orderfilter',
            //         type: 'get',
            //         data: {
            //             'filter': $fliterStatus
            //         },
            //         success: function(response) {
            //             var $list;
            //             if (response.length == 0) {
            //                 $list = `<tr>No Data Found!</tr>`
            //             } else {
            //                 $.each(response, function(index, order) {
            //                         $list += `<tr>
        //                                 <input type="hidden" id="orderId" value=" ${order.order_id} ">
        //                                 <td> ${order.user_id}  </td>
        //                                 <td> ${order.name}  </td>
        //                                 <td> ${order.order_date} </td>
        //                                 <td> ${order.order_code}  </td>
        //                                 <td> ${order.total_price}  Kyats </td>

        //                                 <td>
        //                                     <select class="form-select" name="" id="orderstatus">
        //                                         <option value="pending" ${order.status == 'pending' ? 'selected' : ''}>Pending</option>
        //                                         <option value="processing" ${order.status == 'processing' ? 'selected' : ''}>Processing</option>
        //                                         <option value="delivered" ${order.status == 'delivered' ? 'selected' : ''}>Delivered</option>
        //                                         <option value="rejected" ${order.status == 'rejected' ? 'selected' : ''}>Rejected</option>
        //                                     </select>
        //                                 </td>
        //                                 <td>
        //                                     <button class="btn btn-primary confirm" id="confirm">Confirm</button>
        //                                 </td>
        //                             </tr>
        //                             <tr class="spacer"></tr>`;
            //                     }


            //                 )
            //             };
            //             $('#order-data').html($list);
            //         }
            //     })
            // })
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravelproject\pizza_order_system\resources\views/admin/orders/list.blade.php ENDPATH**/ ?>